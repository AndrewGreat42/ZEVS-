package com.zevs.hotelcrm.health;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;

class HealthControllerTest {
    @Test
    void statusIsUp() {
        var response = new HealthController().health();
        assertThat(response).containsEntry("status", "UP");
        assertThat(response).containsEntry("service", "ZEVS Hotel CRM");
    }
}
