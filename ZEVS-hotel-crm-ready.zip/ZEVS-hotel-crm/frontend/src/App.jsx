import { useEffect, useState } from "react";

const modules = [
  { name: "Номерной фонд", description: "Категории, вместимость, цены, свободные даты" },
  { name: "Гости", description: "Карточки, контакты и поиск" },
  { name: "Бронирования", description: "Создание, подтверждение, заезд и выезд" },
  { name: "Сводка", description: "Загрузка номерного фонда и события дня" }
];

export default function App() {
  const [apiStatus, setApiStatus] = useState("Проверяем подключение…");

  useEffect(() => {
    fetch("/api/health")
      .then((response) => {
        if (!response.ok) throw new Error("Backend недоступен");
        return response.json();
      })
      .then((data) => setApiStatus(data.status === "UP" ? "Backend работает" : "Неизвестный ответ"))
      .catch(() => setApiStatus("Backend не запущен"));
  }, []);

  return (
    <div className="layout">
      <aside className="sidebar">
        <h1>ZEVS<span> / CRM</span></h1>
        <p className="subtitle">Малый отель · Учебный проект</p>
        <nav aria-label="Навигация (план)">
          <div className="menu active">Обзор проекта</div>
          <div className="menu">Номера · скоро</div>
          <div className="menu">Гости · скоро</div>
          <div className="menu">Бронирования · скоро</div>
        </nav>
      </aside>
      <main className="content">
        <header className="header">
          <div><small>УЧЕБНЫЙ ПРОЕКТ / НАЧАЛЬНЫЙ КАРКАС</small><h2>Панель управления</h2></div>
          <span className="status">{apiStatus}</span>
        </header>
        <section className="hero">
          <h3>Управление небольшим отелем в одной системе</h3>
          <p>Это демонстрационная оболочка будущей CRM. Ниже перечислены модули, которые команда разработает в течение семестра.</p>
        </section>
        <section className="cards" aria-label="Модули будущей CRM">
          {modules.map((m) => (
            <article className="card" key={m.name}>
              <span className="diamond">◆</span>
              <h4>{m.name}</h4>
              <p>{m.description}</p>
              <span className="pill">В плане MVP</span>
            </article>
          ))}
        </section>
        <p className="footer">Требования, ER-диаграмма, план, роли и смета — в папке docs/ репозитория.</p>
      </main>
    </div>
  );
}
